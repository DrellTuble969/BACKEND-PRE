# Campus Connect - Backend

Node.js + Express REST API with PostgreSQL. This is **Phase 2 (scaffold only)**:
the server, configuration, error handling and health checks. Business features come in later phases.

## What works now

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Server is running (needs no database) |
| GET | `/api/health/db` | PostgreSQL is reachable (`503` until it is configured) |

All responses use one shape:

```json
{ "success": true,  "data": { } }
{ "success": false, "error": { "code": "NOT_FOUND", "message": "..." } }
```

## Setup (Windows, PowerShell in VS Code)

From the project folder that contains `BACKEND` and `FRONTEND`:

```powershell
cd BACKEND
npm install
Copy-Item .env.example .env
npm run dev
```

Then open <http://localhost:4000/api/health> in your browser.

Edit `.env` with your own PostgreSQL details when PostgreSQL is installed.
**Never commit `.env`** - `.gitignore` already excludes it.

## Commands

| Command | What it does |
|---|---|
| `npm run dev` | Starts the server and restarts it when you save a file |
| `npm start` | Starts the server normally |
| `npm test` | Runs the automated tests |

## Folder guide

```text
BACKEND/
  src/
    config/       env.js (settings), db.js (PostgreSQL pool)
    controllers/  read the request, send the response
    routes/       list the URLs
    middleware/   shared steps (error handling now; login checks later)
    utils/        small helpers (AppError)
    app.js        builds the Express app
    server.js     starts listening
  tests/          automated tests (Node's built-in test runner)
  database/       migrations and seeds (empty until Phase 3)
```

Request flow so far: `Browser/React -> Express (CORS, JSON) -> route -> controller -> JSON response`.
Services and validators will be added when the first feature needs them.

## Common problems

- **`Port 4000 is already in use`** - another program uses that port. Close it or change `PORT` in `.env`
  (and `API_PROXY_TARGET` for Vite if you do).
- **`/api/health/db` says `DATABASE_NOT_CONFIGURED`** - expected until you fill in the `DB_*` values.
- **`/api/health/db` says `DATABASE_UNREACHABLE`** - PostgreSQL is not running, or the host/port/user/password/name is wrong.
- **`npm` is not recognised** - install Node.js LTS from nodejs.org, then reopen VS Code.
