# Database

Nothing has been created or migrated yet.

No SQL files, migrations or existing schema were found in the original project, so the
schema will be designed and documented in **Phase 3** and reviewed before anything is applied.

Planned folders (created when they are first needed):

- `migrations/` - numbered SQL files that create or change tables
- `seeds/` - optional starter data (for example the college list)

No destructive command (DROP, TRUNCATE, DELETE) will be run without explicit approval.
