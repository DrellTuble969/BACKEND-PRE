// Builds the Express app. Kept separate from server.js so tests can use it without opening a port.
const express = require('express');
const cors = require('cors');
const { config } = require('./config/env');
const apiRoutes = require('./routes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();

app.disable('x-powered-by'); // do not advertise that this is Express

// Only the React app's address may call this API from a browser.
// credentials: true is needed later so the login cookie is sent.
app.use(cors({ origin: config.clientOrigin, credentials: true }));

app.use(express.json({ limit: '100kb' }));

app.use('/api', apiRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
