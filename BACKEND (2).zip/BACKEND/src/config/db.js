// One shared PostgreSQL connection pool for the whole app.
// The pool is created only when first needed, so the server can start
// even before PostgreSQL has been configured.
const { Pool } = require('pg');
const { config } = require('./env');

let pool = null;

function getPool() {
  if (!config.db.isConfigured) return null;

  if (!pool) {
    pool = new Pool({
      host: config.db.host,
      port: config.db.port,
      database: config.db.database,
      user: config.db.user,
      password: config.db.password,
      max: 10,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 5_000,
    });

    // Without this handler, an error on an idle connection would crash the server.
    pool.on('error', (err) => {
      console.error('Unexpected PostgreSQL pool error:', err.code || err.message);
    });
  }

  return pool;
}

// Safe check used by the database health endpoint. Never throws and never returns secrets.
async function checkConnection() {
  const activePool = getPool();
  if (!activePool) return { configured: false, connected: false };

  try {
    await activePool.query('SELECT 1');
    return { configured: true, connected: true };
  } catch (err) {
    console.error('PostgreSQL health check failed:', err.code || err.message);
    return { configured: true, connected: false };
  }
}

async function closePool() {
  if (pool) {
    await pool.end();
    pool = null;
  }
}

module.exports = { getPool, checkConnection, closePool };
