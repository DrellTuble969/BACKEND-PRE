// Loads settings from the .env file (if there is one) and exposes them in one place.
// Other files import `config` from here instead of reading process.env directly.
const path = require('node:path');
const dotenv = require('dotenv');

dotenv.config({ path: path.join(__dirname, '..', '..', '.env'), quiet: true });

const text = (name, fallback = '') => String(process.env[name] ?? fallback).trim();

const number = (name, fallback) => {
  const value = Number.parseInt(process.env[name], 10);
  return Number.isInteger(value) && value > 0 ? value : fallback;
};

const config = {
  nodeEnv: text('NODE_ENV', 'development'),
  port: number('PORT', 4000),
  clientOrigin: text('CLIENT_ORIGIN', 'http://localhost:5173'),
  db: {
    host: text('DB_HOST'),
    port: number('DB_PORT', 5432),
    database: text('DB_NAME'),
    user: text('DB_USER'),
    password: text('DB_PASSWORD'),
  },
};

config.isProduction = config.nodeEnv === 'production';

// The server must still start when the database is not set up yet,
// so we only record whether the settings are complete.
config.db.isConfigured = Boolean(
  config.db.host && config.db.database && config.db.user && config.db.password,
);

module.exports = { config };
