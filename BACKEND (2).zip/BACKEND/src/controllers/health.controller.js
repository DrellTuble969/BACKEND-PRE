const { config } = require('../config/env');
const { checkConnection } = require('../config/db');

// GET /api/health - works even when PostgreSQL is not configured.
function getHealth(req, res) {
  res.json({
    success: true,
    data: {
      status: 'ok',
      service: 'campus-connect-api',
      environment: config.nodeEnv,
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: new Date().toISOString(),
    },
  });
}

// GET /api/health/db - runs "SELECT 1". Reveals no credentials or connection details.
async function getDatabaseHealth(req, res) {
  const result = await checkConnection();

  if (!result.configured) {
    return res.status(503).json({
      success: false,
      error: {
        code: 'DATABASE_NOT_CONFIGURED',
        message: 'Database settings are missing. Fill in the DB_* values in your .env file.',
      },
    });
  }

  if (!result.connected) {
    return res.status(503).json({
      success: false,
      error: {
        code: 'DATABASE_UNREACHABLE',
        message: 'Could not connect to PostgreSQL. Check that it is running and that the DB_* values are correct.',
      },
    });
  }

  return res.json({ success: true, data: { status: 'ok', database: 'connected' } });
}

module.exports = { getHealth, getDatabaseHealth };
