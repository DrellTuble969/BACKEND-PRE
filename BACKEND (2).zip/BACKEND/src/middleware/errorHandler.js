// Not-found and error handling, so every failure returns the same JSON shape:
// { "success": false, "error": { "code": "...", "message": "..." } }
const AppError = require('../utils/AppError');

function notFound(req, res, next) {
  next(new AppError(404, 'NOT_FOUND', `Route not found: ${req.method} ${req.originalUrl}`));
}

// Express recognises an error handler by its four parameters. Do not remove "next".
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);

  let status = 500;
  let code = 'INTERNAL_ERROR';
  let message = 'Something went wrong on the server.';

  if (err instanceof AppError) {
    status = err.statusCode;
    code = err.errorCode;
    message = err.message;
  } else if (err.type === 'entity.parse.failed') {
    status = 400;
    code = 'INVALID_JSON';
    message = 'The request body is not valid JSON.';
  } else if (err.type === 'entity.too.large') {
    status = 413;
    code = 'PAYLOAD_TOO_LARGE';
    message = 'The request body is too large.';
  }

  // Details of unexpected errors stay in the server log. They are never sent to the browser.
  if (status >= 500) console.error(`${req.method} ${req.originalUrl} ->`, err);

  return res.status(status).json({ success: false, error: { code, message } });
}

module.exports = { notFound, errorHandler };
