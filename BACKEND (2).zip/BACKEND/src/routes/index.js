// Every API route group is mounted here. Later phases add auth, activities, etc.
const { Router } = require('express');
const healthRoutes = require('./health.routes');

const router = Router();

router.use('/health', healthRoutes);

module.exports = router;
