// Starts the HTTP server. Run with: npm run dev
const app = require('./app');
const { config } = require('./config/env');
const { closePool } = require('./config/db');

const server = app.listen(config.port, () => {
  console.log(`Campus Connect API running on http://localhost:${config.port}`);
  console.log(`Environment: ${config.nodeEnv}`);
  console.log(
    config.db.isConfigured
      ? 'Database settings found in .env (connection is checked at /api/health/db).'
      : 'Database settings not set yet. The server works, but /api/health/db will report this.',
  );
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${config.port} is already in use. Close the other program or change PORT in .env.`);
  } else {
    console.error('Server failed to start:', err.message);
  }
  process.exit(1);
});

function shutdown(signal) {
  console.log(`${signal} received. Shutting down...`);
  server.close(async () => {
    await closePool();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref(); // force-exit if something hangs
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
