// An error we throw on purpose (for example "not allowed" or "not found").
// The error handler turns it into a clean JSON response with the right status code.
class AppError extends Error {
  constructor(statusCode, errorCode, message) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.errorCode = errorCode;
  }
}

module.exports = AppError;
