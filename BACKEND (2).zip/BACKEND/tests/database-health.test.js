// Simulates "settings filled in, but PostgreSQL is not reachable" (nothing listens on port 1).
const test = require('node:test');
const assert = require('node:assert/strict');
const { config } = require('../src/config/env');
const { closePool } = require('../src/config/db');

Object.assign(config.db, {
  host: '127.0.0.1', port: 1, database: 'nope', user: 'nope', password: 'nope', isConfigured: true,
});

const app = require('../src/app');
const { startTestServer } = require('./helpers');

let api;
test.before(async () => { api = await startTestServer(app); });
test.after(async () => { await api.close(); await closePool(); });

test('GET /api/health/db returns 503 and hides connection details when PostgreSQL is unreachable', async () => {
  const res = await fetch(`${api.baseUrl}/api/health/db`);
  const text = await res.text();
  const body = JSON.parse(text);
  assert.equal(res.status, 503);
  assert.equal(body.error.code, 'DATABASE_UNREACHABLE');
  assert.ok(!text.includes('127.0.0.1'), 'host must not leak');
  assert.ok(!text.includes('nope'), 'credentials must not leak');
});

test('GET /api/health still works while the database is down', async () => {
  const res = await fetch(`${api.baseUrl}/api/health`);
  assert.equal(res.status, 200);
});
