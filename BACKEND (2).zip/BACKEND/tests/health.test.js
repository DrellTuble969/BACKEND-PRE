// Simulates "PostgreSQL not configured yet": blank DB settings BEFORE the app loads.
for (const name of ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) process.env[name] = '';

const test = require('node:test');
const assert = require('node:assert/strict');
const app = require('../src/app');
const { startTestServer } = require('./helpers');

let api;
test.before(async () => { api = await startTestServer(app); });
test.after(async () => { await api.close(); });

test('GET /api/health works without any database settings', async () => {
  const res = await fetch(`${api.baseUrl}/api/health`);
  const body = await res.json();
  assert.equal(res.status, 200);
  assert.equal(body.success, true);
  assert.equal(body.data.status, 'ok');
});

test('GET /api/health/db reports "not configured" with 503', async () => {
  const res = await fetch(`${api.baseUrl}/api/health/db`);
  const body = await res.json();
  assert.equal(res.status, 503);
  assert.equal(body.success, false);
  assert.equal(body.error.code, 'DATABASE_NOT_CONFIGURED');
});

test('unknown routes return a JSON 404', async () => {
  const res = await fetch(`${api.baseUrl}/api/does-not-exist`);
  const body = await res.json();
  assert.equal(res.status, 404);
  assert.equal(body.error.code, 'NOT_FOUND');
});

test('malformed JSON returns a JSON 400 instead of crashing', async () => {
  const res = await fetch(`${api.baseUrl}/api/health`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: '{ not valid json',
  });
  const body = await res.json();
  assert.equal(res.status, 400);
  assert.equal(body.error.code, 'INVALID_JSON');
});

test('responses do not reveal that the server runs Express', async () => {
  const res = await fetch(`${api.baseUrl}/api/health`);
  assert.equal(res.headers.get('x-powered-by'), null);
});
